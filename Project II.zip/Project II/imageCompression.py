from matplotlib.image import imread
import matplotlib.pyplot as plt
import numpy as np
import os

#parameters
plt.rcParams['figure.figsize']=[8,8]
A = imread('dog.jpg')
X = np.mean(A,-1); #convert rgb to grayscale
U, S, VT = np.linalg.svd(X,full_matrices=False)
S = np.diag(S)

#store original versus compression images, 1 row 5 columns  
figure, x = plt.subplots(1,5, figsize=(16,8))
#show original pic
x[0].imshow(A)
x[0].set_title("Original")
x[0].axis("off")

#set values of r
valueOf_r = [5,20,50,100]
for i,r in enumerate(valueOf_r):
    #using svd through computation
    Xapprox = U[:,:r] @ S[0:r,:r] @ VT[:r,:]
    #index of row and column
    row = (i+1)//5
    column = (i+1) % 5
    #set image on subplot
    x[column].imshow(Xapprox, cmap='gray')
    x[column].set_title('r= '+str(r))
    x[column].axis('off')
plt.show()

#singular values graph
plt.figure(2)
plt.semilogy(np.diag(S))
plt.title('Singular Values')
plt.show()
#cumulative sum of singular values
plt.figure(3)
plt.plot(np.cumsum(np.diag(S))/np.sum(np.diag(S)))
plt.title('Singular Values: Cumulative Sum')
plt.show()