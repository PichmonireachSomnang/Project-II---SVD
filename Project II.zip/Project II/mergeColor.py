import cv2
import os
import glob

original = cv2.imread('dog.jpg', cv2.IMREAD_UNCHANGED)

dim = (450, 450)
 
b, g, r = cv2.split(original)

cv2.imshow("Blue Channel", b)

cv2.imshow("Green Channel", g)

cv2.imshow("Red Channel", r)


merged = cv2.merge((b,g,r))
merged_resized = cv2.resize(merged,dim)
cv2.imshow("Merged Image", merged_resized)
cv2.waitKey(0)